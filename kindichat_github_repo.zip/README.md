# KindiChat

This repository contains the KindiChat React Native project and supporting infrastructure.

## What is included
- kindichat_rn_full: full React Native Android project (android/ folder included)
- firebase_starter: Firestore rules and Cloud Functions sample
- assets: icon.png and splash.png
- build helpers and CI workflow example

## How to publish to GitHub

1. Initialize git (if not already)
```bash
cd kindichat_github_repo
git init
git add .
git commit -m "Initial commit - KindiChat"
```

2. Create a new GitHub repository (on github.com) named `kindichat` and follow instructions to add remote:
```bash
git remote add origin https://github.com/YOUR_USERNAME/kindichat.git
git branch -M main
git push -u origin main
```

3. Set GitHub Secrets (in repo Settings -> Secrets):
- EXPO_TOKEN (if using EAS)
- FIREBASE_SERVICE_ACCOUNT (if deploying functions)
- ANDROID_KEYSTORE_PASSWORD / etc. (for CI, if needed)

## Build
See kindichat_rn_full/README.md for local build instructions and kindichat_build_helpers/README.md for helper scripts.

