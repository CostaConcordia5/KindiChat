KindiChat - Firebase Starter

Includes:
- Firestore basic schema suggestion
- Firestore security rules (example)
- Cloud Function: sendNotification (uses FCM)
- Note: You must enable Firebase project, set up environment variables for Twilio if using SMS.

Usage:
1. Create Firebase project
2. Install Firebase CLI
3. Deploy rules and functions:
   firebase deploy --only firestore:rules,functions
