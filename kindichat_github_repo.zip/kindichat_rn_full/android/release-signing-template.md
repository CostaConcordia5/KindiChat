# Keystore & Signing Guide (template)
This file explains how to create a keystore and configure Gradle for signing the release AAB/APK.

1. Generate a keystore (run on your machine):
   keytool -genkey -v -keystore kindichat-release.keystore -alias kindichat -keyalg RSA -keysize 2048 -validity 10000

2. Move the keystore into android/app (or keep it in a secure location).

3. In android/gradle.properties (DO NOT COMMIT KEYS), add:
   KINdICHAT_KEYSTORE_PATH=android/app/kindichat-release.keystore
   KINdICHAT_KEY_ALIAS=kindichat
   KINdICHAT_KEY_PASSWORD=your_keystore_password
   KINdICHAT_KEYSTORE_PASSWORD=your_keystore_password

4. In android/app/build.gradle add signingConfigs referencing the properties (example snippet in android/app/build.gradle.example).
