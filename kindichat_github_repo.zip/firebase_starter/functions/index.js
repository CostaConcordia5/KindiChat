const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

// Example: Send push notification via FCM
exports.sendNotification = functions.https.onCall(async (data, context) => {
  const { token, title, body } = data;
  if (!token) throw new functions.https.HttpsError('invalid-argument', 'No token provided');
  const message = {
    token,
    notification: { title: title || 'KindiChat', body: body || '' }
  };
  try {
    const res = await admin.messaging().send(message);
    return { success: true, result: res };
  } catch (err) {
    throw new functions.https.HttpsError('internal', err.message);
  }
});
